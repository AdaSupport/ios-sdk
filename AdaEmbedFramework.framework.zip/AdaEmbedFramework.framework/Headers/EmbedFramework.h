//
//  EmbedFramework.h
//  EmbedFramework
//
//  Created by Nicholas Haley on 2019-04-23.
//  Copyright © 2019 Ada Support. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EmbedFramework.
FOUNDATION_EXPORT double EmbedFrameworkVersionNumber;

//! Project version string for EmbedFramework.
FOUNDATION_EXPORT const unsigned char EmbedFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EmbedFramework/PublicHeader.h>


